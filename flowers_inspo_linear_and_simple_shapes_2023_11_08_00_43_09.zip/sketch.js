
let a;
let b;
let c;

function setup() {
  createCanvas(720, 400);
  stroke(255);
  a = height;
  b = height;
  c = height;
}

function draw() {
  background(51);
  a = a + 3.5;
  if (a > 430) {
    a = 0;
  }  
  translate(360, a);
  for (let i = 0; i < 10; i ++) {
    fill('rgb(232, 125, 216)')
    ellipse(0, 15, 10, 40);
    rotate(PI/5);
  }
    translate(360, a);
  for (let i = 0; i < 10; i ++) {
    fill('rgb(21, 104, 230)')
    ellipse(0, 15, 10, 40);
    rotate(PI/5);
  }
    translate(-700, a);
  for (let i = 0; i < 10; i ++) {
    fill('	rgb(255,255,0)')
    ellipse(0, 15, 10, 40);
    rotate(PI/5);
  }
  translate(540, a);
  for (let i = 0; i < 10; i ++) {
    fill('	rgb(255, 164, 84)')
    ellipse(0, 15, 10, 40);
    rotate(PI/5);
  }
  translate(-350, a);
  for (let i = 0; i < 10; i ++) {
    fill('	rgb(109, 156, 92)')
    ellipse(0, 15, 10, 40);
    rotate(PI/5);
  }
}